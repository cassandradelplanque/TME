import base64
import hashlib

from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad

iv=bytes.fromhex("ca0f9549b0ec69503c78d16e74586e2b")

with open("message_uglix.txt", "r") as file:
    raw_message = file.read().strip()  # on supprime les retours à la ligne et espaces
    # Ajout du padding manquant si nécessaire
    padding = len(raw_message) % 4
    if padding:
        raw_message += '=' * (4 - padding)
    message = base64.b64decode(raw_message)



def key_expansion(seed : bytes) -> bytes:
  """
  Renvoie 256 bits pseudo-aléatoires à partir de seed
  """
  state = seed
  output = b''
  for i in range(8):
    state = hashlib.sha256(state).digest()
    output += state[:4]
  return output



    
for a in range(256):
    for b in range(256):
        seed = bytes([a, b])
        key_material = key_expansion(seed)
        K = key_material[0:16]
        IV = key_material[16:32]
        if IV == iv:
          print("je passe")
          cipher = AES.new(K, AES.MODE_CBC, iv)
          decrypted = cipher.decrypt(message)
          unpadded = unpad(decrypted, AES.block_size)
          print("Message déchiffré:", unpadded.decode('utf-8'))