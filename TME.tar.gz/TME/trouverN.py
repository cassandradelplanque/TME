import sympy
from Crypto.PublicKey import RSA

with open("wetsarah_public.pem", "rb") as f1:
    pub_key_pem_1 = f1.read()
with open("andrea77_public.pem", "rb") as f2:
    pub_key_pem_2 = f2.read()

key1 = RSA.import_key(pub_key_pem_1)
key2 = RSA.import_key(pub_key_pem_2)

d1 = int("258600afead219a7ceefe91b60736014472aabc636a26be0e7a085fd68054f2fa8026aa84c954b5fe3bb90e8548a3f25a9cbef52bb3fa6d55803cb318085015bb714d5392194b8570326c64a04f71691a449b1a56bbc3d659c0e013044acfffe7dbca47c64591ae1cee7d5f0c05aebf94dff09db12cc2f329858b87e759c13ec3f6d7b392ccb34d90f3bc18994fb4473e460dff6cf73d817e934031281679431575477cfd515b2286801d8d4b6707f4842b6b1c7e658d58e0a99303568049a2c64dc4bf4151a31f8f5eccfaa56076a7d757a386dd9e83d939e440389bf1d62f5e1528fdff624ce6b18f1846b9eb77a45da165781ccd806f3d3110a2f36bf49bd", 16)

key_private_1 = RSA.construct((key1.n, key1.e, d1))

with open("wetsarah_private.pem", 'wb') as f:
    f.write(key_private_1.export_key())
d2 = sympy.mod_inverse(key2.e, (key_private_1.p - 1) * (key_private_1.q - 1)) 
key_private_2 = RSA.construct((key2.n, key2.e, d2))

with open("andrea77_private.pem", 'wb') as f:
    f.write(key_private_2.export_key()) 

