import binascii
import json
from datetime import datetime

from cryptography import x509
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, padding, rsa
from cryptography.x509.oid import NameOID

# Charger le contenu du fichier JSON
with open('cartes.json', 'r', encoding='utf-8') as f:
    cartes = json.load(f)

liste= []
for carte in cartes["batch"]["transactions"]:
    test=1
    cert_card = x509.load_pem_x509_certificate(carte["card"]["certificate"].encode(), default_backend())
    cert_bank = x509.load_pem_x509_certificate(carte["card"]["bank"]["certificate"].encode(), default_backend())
    with open("certificat_ca.pem", "rb") as f:
      cert_ca = x509.load_pem_x509_certificate(f.read(), default_backend())
    signature = binascii.unhexlify(carte["signature"])
    data = carte["data"].encode('utf-8')
    try:
      cert_card.public_key().verify(signature,data, ec.ECDSA(hashes.SHA256()))
      print("✔️ Signature RSA valide")
    except Exception as e:
      test=0
      print("❌ Signature RSA invalide :")
    try:
      if (cert_bank.extensions.get_extension_for_class(x509.BasicConstraints)):
          print("✔️bit CA valid")
      else:
        test=0
        print("❌bit CA invalid")
    except Exception as e:
       test=0
       print("❌bit CA invalid")
    try:
      cert_bank.public_key().verify(cert_card.signature,cert_card.tbs_certificate_bytes)
      print("✔️ certificat Carte signé par certificat banque")
    except Exception as e:
      test=0
      print("❌  certificat Carte pas signé par certificat banque")
    for attr in cert_bank.subject:
        if(attr.oid == x509.NameOID.COMMON_NAME and attr.value==carte["card"]["bank"]["name"] and attr.value==json.loads(carte["data"])["bank-name"]):
           print("✔️bonne banque")
        else:
           test=0
           print("❌ mauvaise banque")
    for attribute in cert_bank.issuer:
      if(attribute.value=="__CA__"):
         print("✔️ CA valide")
      else:
         test=0
         print("❌ CA invalide")
    try:
      cert_ca.public_key().verify(cert_bank.signature,cert_bank.tbs_certificate_bytes,padding.PKCS1v15(),cert_bank.signature_hash_algorithm)
      print("✔️ Certificat banque signé par CA")
    except Exception as e:
      test=0
      print("❌ Certificat banque pas signé par CA")
    if(carte["card"]["number"]==json.loads(carte["data"])["card-number"] and cert_card.subject.get_attributes_for_oid(NameOID.COMMON_NAME)[0].value==carte["card"]["number"]):
       print("✔️ Good card number")
    else:
      test=0
      print("❌ Bad card number")
    print("\n")
    liste.append(test)
print(liste)

      