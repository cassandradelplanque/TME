import base64
import binascii
import math
import random
import subprocess

from sympy import isprime, nextprime

# ce script suppose qu'il a affaire à OpenSSL v1.1.1
# vérifier avec "openssl version" en cas de doute.
# attention à MacOS, qui fournit à la place LibreSSL.

# en cas de problème, cette exception est déclenchée
class OpensslError(Exception):
    pass

# Il vaut mieux être conscient de la différence entre str() et bytes()

def encrypt(plaintext, passphrase, cipher='aes-128-cbc'):
    """invoke the OpenSSL library (though the openssl executable which must be
       present on your system) to encrypt content using a symmetric cipher.

       The passphrase is an str object (a unicode string)
       The plaintext is str() or bytes()
       The output is bytes()

       # encryption use
       >>> message = "texte avec caractères accentués"
       >>> c = encrypt(message, 'foobar')       
    """
    # prépare les arguments à envoyer à openssl
    pass_arg = 'pass:{}'.format(passphrase)
    args = ['openssl', 'enc', '-' + cipher, '-base64', '-pass', pass_arg, '-pbkdf2']
    
    # si plaintext est de stype str, on est obligé de l'encoder en bytes pour
    # pouvoir l'envoyer dans le pipeline vers openssl
    if isinstance(plaintext, str):
        plaintext = plaintext.encode('utf-8')
    
    # ouvre le pipeline vers openssl. envoie plaintext sur le stdin de openssl, récupère stdout et stderr
    #    affiche la commande invoquée
    #    print('debug : {0}'.format(' '.join(args)))
    result = subprocess.run(args, input=plaintext, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    # si un message d'erreur est présent sur stderr, on arrête tout
    # attention, sur stderr on récupère des bytes(), donc on convertit
    error_message = result.stderr.decode()
    if error_message != '':
        raise OpensslError(error_message)

    # OK, openssl a envoyé le chiffré sur stdout, en base64.
    # On récupère des bytes, donc on en fait une chaine unicode
    return result.stdout.decode()




def decrypt(ciphertext, passphrase, cipher='aes-128-cbc'):

    pass_arg = f'pass:{passphrase}'
    args = ['openssl', 'enc', '-d', '-' + cipher, '-base64', '-pbkdf2', '-pass', pass_arg]

    if isinstance(ciphertext, str):
        ciphertext = ciphertext.encode('utf-8')

    result = subprocess.run(args, input=ciphertext, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    error_message = result.stderr.decode()
    if error_message != '':
        raise OpensslError(error_message)
    
    return result.stdout.decode()





def public_key(message, public_key_file='cle_pub.pem'):

    args = ['openssl', 'pkeyutl', '-encrypt', '-pubin', '-inkey', public_key_file]
    
    # si plaintext est de stype str, on est obligé de l'encoder en bytes pour
    # pouvoir l'envoyer dans le pipeline vers openssl
    if isinstance(message, str):
       message = message.encode('utf-8')
    
    # ouvre le pipeline vers openssl. envoie plaintext sur le stdin de openssl, récupère stdout et stderr
    #    affiche la commande invoquée
    #    print('debug : {0}'.format(' '.join(args)))
    result = subprocess.run(args, input=message, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    # si un message d'erreur est présent sur stderr, on arrête tout
    # attention, sur stderr on récupère des bytes(), donc on convertit
    error_message = result.stderr.decode()
    if error_message != '':
        raise OpensslError(error_message)

    # OK, openssl a envoyé le chiffré sur stdout, en base64.
    # On récupère des bytes, donc on en fait une chaine unicode
    
    encrypted_hex = binascii.hexlify(result.stdout).decode()
    return encrypted_hex

def generate_key():
    args = ['openssl', 'genpkey', '-algorithm', 'RSA', '-out', 'private_key.pem']
    result = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    args = ['openssl', 'rsa', '-in', 'private_key.pem', '-pubout', '-out', 'public_key.pem']
    result = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return result


def sign():
    args = ['openssl', 'dgst', '-sha256', '-hex' , '-sign', 'private_key.pem', '-out', 'signature.bin', 'message.txt']
    
    result = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    return result


def decrypt2(encrypted_text, passphrase, cipher='aes-128-cbc'):
    """Déchiffre un texte avec OpenSSL en AES-128-CBC."""
    
    pass_arg = 'pass:{}'.format(passphrase)
    args = ['openssl', 'enc', '-d', '-' + cipher, '-base64', '-pbkdf2', '-pass', pass_arg]
    
    if isinstance(encrypted_text, str):
        encrypted_text = encrypted_text.encode('utf-8')  # Convertir en bytes
    
    # Exécute OpenSSL en mode déchiffrement
    result = subprocess.run(args, input=encrypted_text, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    # Vérifier si OpenSSL a retourné une erreur
    if result.stderr:
        return None  # Erreur de déchiffrement

    return result.stdout.strip()  # Retourner le texte déchiffré en bytes


def doc():
    with open("words.txt", "r", encoding="utf-8") as file:
        for line in file:
            word = line.strip()

            try:
                decrypted = decrypt2("U2FsdGVkX1/LKCFGfl+cLj9TjgLkfRGMBpjQ8wHzP/gPSlTi/vsczOwk6hWcCljm\n", word)
                
                if decrypted == b'shank tunas piths razed sated':
                    print(f"Clé trouvée : {word}")
                    return word  # Retourne la clé correcte
            
            except Exception as e:
                print(f"Erreur avec {word} : {e}")
                continue  # Continue avec le mot suivant en cas d'erreur

    return None  # Si aucune clé ne correspond


import random


def is_prime(n, k=40):
    """Teste si n est premier avec le test probabiliste de Miller-Rabin.
    
    Paramètres :
    - n : entier à tester
    - k : nombre d'itérations du test (plus grand = plus fiable)
    
    Retourne :
    - True si n est probablement premier
    - False si n est composé
    """
    if n < 2:
        return False
    if n in (2, 3, 5, 7, 11, 13, 17, 19, 23, 29):  # Vérification rapide des petits nombres premiers
        return True
    if n % 2 == 0:
        return False

    # Décomposition de n-1 sous la forme d * 2^r
    r, d = 0, n - 1
    while d % 2 == 0:
        r += 1
        d //= 2

    # Test de Miller-Rabin avec k bases aléatoires
    for _ in range(k):
        a = random.randint(2, n - 2)
        x = pow(a, d, n)
        if x == 1 or x == n - 1:
            continue
        for _ in range(r - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False  # n est composé

    return True  # n est probablement premier






def poste1_TME(q, a, b):
    lower_bound = (a - 1) // q
    upper_bound = (b - 1) // q
    l = random.randint(lower_bound, upper_bound)
    p=q*l+1
    if isprime(p):
        while(g==1):
            x= random.randint(2, p)
            g = (x**l)%p
        return(p, g) 
        


def sign2():
    args = ['openssl', 'dgst', '-sha256', '-hex' , '-sign', 'private_key.pem', '-out', 'signature_cassie.bin', 'cassie_public.pem']
    
    result = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    return result

#decrypt
#print(decrypt( 'U2FsdGVkX18f+jojtREj+TYnkC69L/THct025OWoo0BRq+EMIs+At1oRegPUD6Sw\nzWSeLxbEQaK+ptKY1VMQRQ==', 'ISECR0XX'))
#fait public key
#print(public_key("I got it!"))
#générer clef
#generate_key()
#signer
#sign()
#signer clef autre
sign2() 
