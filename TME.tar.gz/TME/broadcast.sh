#!/bin/bash

# 1. Générer une clé de session aléatoire (128 bits)
cle_session=$(openssl rand -hex 16)

# Afficher la clé de session générée
echo "Clé de session générée : $cle_session"

# 2. Écrire la clé de session dans un fichier
echo "$cle_session" > cle_session.txt

# Message à chiffrer
message="hello"

# 3. Chiffrement du message avec la clé de session
ciphertext=$(echo -n "$message" | openssl enc -aes-128-cbc -base64 -pass pass:"$cle_session" -pbkdf2)

# Afficher le texte chiffré
echo "Message chiffré : $ciphertext"

# 4. Clé publique du secrétaire (vérifie le chemin du fichier)
cle_publique_secretaire="broadcast.pem"

# 5. Chiffrement de la clé de session avec la clé publique
cle_session_chiffree=$(echo -n "$cle_session" | openssl pkeyutl -encrypt -pubin -inkey "$cle_publique_secretaire" | xxd -p| tr -d '\n')

# Afficher la clé de session chiffrée
echo "Clé de session chiffrée : $cle_session_chiffree"
ciphertext_with_newline="${ciphertext}\n"
# 6. Créer un fichier JSON contenant la clé chiffrée et le texte chiffré
echo "{
  \"session-key\": \"$cle_session_chiffree\",
  \"ciphertext\": \"$ciphertext_with_newline\"
}" > final.json

