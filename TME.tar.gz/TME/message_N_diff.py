import sympy
from Crypto.PublicKey import RSA
from gmpy2 import iroot
from sympy.ntheory.modular import crt

# Chargement des clés publiques
with open("pauldavis_public.pem", "rb") as f1:
    pub_key_pem_1 = f1.read()
with open("kevin79_public.pem", "rb") as f2:
    pub_key_pem_2 = f2.read()
with open("savannahreynolds_public.pem", "rb") as f3:
    pub_key_pem_3 = f3.read()


key1 = RSA.import_key(pub_key_pem_1)
key2 = RSA.import_key(pub_key_pem_2)
key3 = RSA.import_key(pub_key_pem_3)

c1 = int("3d741c1026134bfbde00b6450f28b228507d96734c2644b7d1d69f9f41562741d6efe86cc88fb505c0ac0d987d72d0c21d9ba66ec42bebca630ee800d1ae67c8027f17cf15d7f5f0716898496da3095d7abc954a193f81ef6ef1a54f3a92a448d881321d6a5e4a9cf6be04af0a6149142b3595c3fecfbf368817d45a85cd205efa743c5cb8d65ce7d6751f22143a3e6f4cabb65fb4e2bfc498cc9810cc14b2933bd4b1bdfc3b680cb33965fff267c93e2c4a0422e4305dc457bef5f5d9b4945e6779fd9f9f5a980f7f0bd53e4762a5ea5f18ff55a3198b266fc16fad93f1eb0ab60b52e431841322ada49b24ad8a0e302d5131fc5138f8a57037d21e6459ea3c", 16)
c2 = int("60820f02593fee32f96a9cf442cd4435c91181ed64c11a9035128a6d228152e3874ae06218c0ad95e34ea90344f0f3552494ea1f0814a68a4c0ae4389421a342523c0848683f297dbfbdf5a86ea37d5eb46f561dae9c69199b15a2bcd1376b4676fa95b2ee0ced905bd2ddde0db08271ff7c1aa4894a4bcf9d68f026feec6e96938c3a3f5527060eb6945ea97a68d228cab06b1be88a1e9edded2ca4f9c04808c5ea4abb7f3539745a571ce6b2570cd1ded9e0026492c2fd57bd113b44d49baafef6769c99b3481accc8a38a93aee9bd1cb6afca990af9c338fa702e817e86b13404e4ff7b3a0c18176e906b8372ab5800cc9a8e538c2046b9f5b9aac50cefa0", 16)
c3 = int("4cc68c0404837fde746c32ce988e0b095a04354c963e89e438a6d51bf1dee81bb3b3317e8a24fa9ca5ca160b0162c428ac31077b5bd91adbc543d3fa14b6f9e1951c822c92207686d32cc65cfa20e60961e16b8d844d90521f77cfd8b958cdeeef65f6102bd94d794ffdee7ffeee55d44408f62f49fe58e0fe117c3020d7084a7101906bd3197f853637f397bcf26129b744b0a737ccf4fd964b2a0ee3497647ad5a728a807c9a2c7595a452d05dc4e6271f231485493abfbb9a9f57e6551b73a1608800dab42850de87728dc97957f7fc74d6d5d76ceba6aa9fb8fc369a1cdb829fadf6e4edb4652f0fe71d036c4c70a3d67762e874671336c7cf92eb0f7ef9", 16)

n = [key1.n, key2.n, key3.n]
c = [c1, c2, c3]
C, _ = crt(n, c)
m, exact = iroot(C, key1.e)



m_bytes = m.to_bytes((m.bit_length() + 7) // 8, 'big')
print(f"Message déchiffré (bytes) : {m_bytes}")








