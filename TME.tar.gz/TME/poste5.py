

import math
import random


def power_modulo(a: int, b: int, n: int):
    result = 1
    while b > 0:
        if b % 2 == 1:
            result = (result * a) % n
        a = (a * a) % n
        b //= 2
    return result

def legendre_symbol(a: int, p: int):
    return power_modulo(a % p, (p - 1) >> 1, p)

def inverse_modulo(a: int, n: int):
    t, new_t = 0, 1
    r, new_r = n, a
    while new_r != 0:
        quotient = r // new_r
        t, new_t = new_t, t - quotient * new_t
        r, new_r = new_r, r - quotient * new_r
    if r > 1:
        raise ValueError("Pas d'inverse")
    return t % n

def tonelli_shanks(n, p):
    """Renvoie x tel que x² ≡ n mod p, ou None si pas de solution"""
    if legendre_symbol(n, p) != 1:
        return None
    if p % 4 == 3:
        return power_modulo(n, (p + 1) // 4, p)
    # écrire p-1 = q * 2^s avec q impair
    q = p - 1
    s = 0
    while q % 2 == 0:
        s += 1
        q //= 2
    # trouver z tel que legendre(z, p) == -1
    z = 2
    while legendre_symbol(z, p) != p - 1:
        z += 1
    c = power_modulo(z, q, p)
    x = power_modulo(n, (q + 1) // 2, p)
    t = power_modulo(n, q, p)
    m = s
    while t != 1:
        i = 1
        temp = (t * t) % p
        while temp != 1:
            temp = (temp * temp) % p
            i += 1
        b = power_modulo(c, 1 << (m - i - 1), p)
        x = (x * b) % p
        t = (t * b * b) % p
        c = (b * b) % p
        m = i
    return x

def cornacchia(p):
    # Chercher une racine carrée de -1 mod p
    Beta = tonelli_shanks(p - 1, p)
    if Beta is None:
        return None, None
    # Algorithme d'Euclide modifié
    a, b = p, Beta
    while b * b > p:
        a, b = b, a % b
    x = b
    y_sq = p - x * x
    y = math.isqrt(y_sq)
    if y * y == y_sq:
        return abs(x), abs(y)
    return None, None



# Le nombre premier donné
p = int("d45654358436b8ed035f118962216feda8824b688e05eb7ea40875ea68a4984937e661a2f28e419b4138e8203549b4995415b2c36c2c4ca874f1fdb6fd383496771111233177d632da10006c9e539dffd45eadb3a220ee7d2e3bf6bdf5c036393a21d852ad4efbaf982a36e9c540050ad0d189165a66a27c2d6094cf3883a19d", 16)

a, b = cornacchia(p)
if a is not None:
    print(f"p = {a}² + {b}² = {a*a + b*b}")
    print(f"Vérification : {a*a + b*b == p}")
    print("\n")
    print(f"a=\n{a}\n b=\n{b}\n")
else:
    print("Aucune solution trouvée.")