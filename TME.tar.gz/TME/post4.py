# TME #3 : certificat de primalité
# ================================
        
import json
import random

from gmpy2 import mpz
from sympy import factorint

# Définition des fonctions utilisées pour le certificat de primalité de Pratt

def json_mpz_encoder(obj):
    """Encodeur personnalisé pour les objets mpz"""
    if isinstance(obj, mpz):
        return int(obj)
    raise TypeError(f"Object of type {obj.__class__.__name__} is not JSON serializable")


def miller_rabin(n, k):
    """ Test de primalité de Miller-Rabin.
    n: entier à tester.
    k: nombre de tours pour augmenter la précision du test.
    Retourne True si n est probablement premier, sinon False. 
    """
    if n in (2, 3):
        return True
    if n % 2 == 0:
        return False
    r, s = 0, n - 1
    while s % 2 == 0:
        r += 1
        s //= 2
    for _ in range(k):
        a = random.randrange(2, n - 1)
        x = pow(a, s, n)
        if x in (1, n - 1):
            continue
        for _ in range(r - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False
    return True

def taille_en_bit(int):
    return (int.bit_length() + 7) // 8

def find_gen(p, list_div):
    while True:
        g = random.randrange(2, p-1)
        if all(pow(g, (p-1)//pi, p) != 1 for pi in list_div):
            return g

def rec_cert_pratt(list_div):
    res = []
    for div in list_div:
        cert_div = {'p': div}
        if div >= 1024:
            diviseur = []
            factors = factorint(div - 1)
            for d, exp in factors.items():
                diviseur.extend([d] * exp)
            cert_div['g'] = find_gen(div, diviseur)
            cert_div['pm1'] = rec_cert_pratt(diviseur)
        res.append(cert_div)
    return res


    
a = int("ab331b4cc731997d4248e2e6609a86d9323b8ad7db0c8d4fd73542ca8d190acdfa2dbefbb16d3255cf53b6b17a089b86325d27cccddc8282578246eb6956428655ad3a2f35b6b100a3d30c04c513edafcd4c0c95625c223dc8ce13f5bc4099fa90972d85b32e4880495a4908d41a7886779e3cc66d3dca4e5dd3c3e3adc900e3", 16)
b = a + 2**960

liste_pk = [2]
P = 2

tailleMax = taille_en_bit((b-a) // (20000 * taille_en_bit(b)**2))

while tailleMax != taille_en_bit(P):
    pi = random.randrange(2, min(pow(2, 160), pow(2, 8 * (tailleMax - taille_en_bit(P)))))
    if miller_rabin(pi, 10):
        P *= pi
        liste_pk.append(pi)

q = random.randrange(a//P, b//P)
while not miller_rabin(q, 1) or not miller_rabin(P*q+1, 1):
    q = random.randrange(a//P, b//P)

liste_pk.append(q)
p = P*q + 1
g = find_gen(p, liste_pk)

if(p<1024):
  cert_pratt = {'p': p}
else:
  cert_pratt = {'p': p, 'g': g, 'pm1': rec_cert_pratt(liste_pk)}

with open('poste4.pratt.json', 'w') as f:
    json.dump(cert_pratt, f, default=json_mpz_encoder)


