import base64

from Crypto.PublicKey import RSA

# La chaîne à encoder
text = "ee+++ATRIUM+++ef"
decoded = base64.b64decode(text)
e = int.from_bytes(decoded, "big")

# Générer la clé RSA avec l'exposant e
key = RSA.generate(2048, e=e)

# Exporter la clé publique au format PEM
pub_key_pem = key.publickey().export_key(format='PEM')
pri_key_pem = key.export_key(format='PEM')


with open("private_key_atrium.pem", 'wb') as f:
        f.write(pri_key_pem)
with open("public_key_atrium.pem", 'wb') as f:
        f.write(pub_key_pem)