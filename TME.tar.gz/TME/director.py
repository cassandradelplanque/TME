
import random
from hashlib import sha256

from Crypto.PublicKey import RSA

# Function names respect those in https://www.ietf.org/rfc/rfc3447.txt

# SHA-256
HASH_ID = b'010\r\x06\t`\x86H\x01e\x03\x04\x02\x01\x05\x00\x04 '

def i2osp(x : int, k : int) -> bytes:
    """
    Convert the integer x to a sequence of k bytes
    """
    return x.to_bytes(k, byteorder='big')

def os2ip(x : bytes) -> int:
    """
    Convert the sequence of bytes to an integer
    """
    return int.from_bytes(x, byteorder='big')

def emsa_pkcs1_encode(M : bytes, k : int) -> bytes:
    """
    Encode a message into k bytes for RSA signature
    """
    h = sha256(M)
    T = HASH_ID + h.digest()
    if len(T) + 11 > k:
        raise ValueError("Message Too Long")
    PS = bytes([0xff] * (k - len(T) - 3))
    EM = bytes([0x00, 0x01]) + PS + bytes([0x00]) + T
    return EM

def emsa_pkcs1_decode(EM : bytes, k : int) -> bytes:
    """
    Given an EMSA_PKCS1-encoded message, returns the Hash
    
    >>> x = emsa_pkcs1_encode("toto", 128)
    >>> emsa_pkcs1_decode(x, 128) == sha256("toto".encode()).digest()
    True
    """
    if len(EM) != k:
        raise ValueError("Incorrect Size")
    if EM[:2] != bytes([0x00, 0x01]):
        raise ValueError("Incorrect Header")
    i = 2
    while EM[i] != 0:
        if EM[i] != 0xff:
            raise ValueError("Incorrect Filler")
        i += 1
        if i == k:
            raise ValueError("Only Filler")
    if i < 10:
        raise ValueError("Not enough filler")
    T = EM[i+1:]
    if T[:len(HASH_ID)] != HASH_ID:
        raise ValueError("Bad Hash ID")
    H = T[len(HASH_ID):]
    return H

def key_length(n : int) -> int:
    """
    key length in bytes
    """
    return (n.bit_length() + 7) // 8

def rsa_pkcs_sign(n : int, d : int, M : bytes):
    """
    RSA Signature using PKCS#1 v1.5 encoding
    """
    k = key_length(n)
    EM = emsa_pkcs1_encode(M, k)
    m = os2ip(EM)
    s = pow(m, d, n)
    S = i2osp(s, k)
    return S

def rsa_pkcs_verify(n : int, e : int, M : bytes, S : bytes) -> bool:
    """
    Verify RSA PKCS#1 v1.5 signatures
    """
    k = key_length(n)
    if len(S) != k:
        raise ValueError("Bad length")
    s = os2ip(S)
    m = pow(s, e, n)
    EM = i2osp(m, k)
    H = emsa_pkcs1_decode(EM, k)
    return (H == sha256(M).digest())



x = 2
with open("director_public.pem", "rb") as f:
    key_pem = f.read()
key = RSA.import_key(key_pem)

M=os2ip(emsa_pkcs1_encode(b"I, the lab director, hereby grant cassandra_delp permission to take the BiblioDrone-NG.", key.size_in_bytes()))
result=(M * pow(x, key.e, key.n)) % key.n
print(f"{result:x}")
x_inv = pow(x, -1, key.n) 
recup= int("bd3e5744eec3ef6a4ff360e4694f4f1bcd8ea05c4b8495431ac225a285500ecd14890e5a5f2ad12c4188e4755663fb37c71f535b00bdc386ed7448062fc3ea3410140bef03c1988cb4f5ad040e3a6bdec0e53aa4de3b40846a4982dda27d5200712c49864f6c4e4670454ee25dd25c5cdf1aa79f99a0d0f7a161a2f26e0d97967221450b5a77d41fc539bf4cd6895e9ae841b61b6d737db0329e953356554f832d0179fb8a7e405000d2d73549b896348d4136032a8dbebf9cee5e95e919192cd93aed5f81a0251a6f5d1020294c5f8096c11a25419ebaac75c82f90b3c93ff763df3fa54472e59889ec27c3208b2d6e034635a894d8c53a9d3b2c38b12e141d", 16)
sig=(x_inv*recup)%key.n
print(f"{sig:x}")