import sympy
from Crypto.PublicKey import RSA

# Chargement des clés publiques
with open("vyoung0_public.pem", "rb") as f1:
    pub_key_pem_1 = f1.read()
with open("amysanchez_public.pem", "rb") as f2:
    pub_key_pem_2 = f2.read()


key1 = RSA.import_key(pub_key_pem_1)
key2 = RSA.import_key(pub_key_pem_2)


c1 = int("828d3b4b1cf259f1344d4b5aa2943e3f41820c23822fb426d62ef8525bfec2f8801a7dc3d253f9aac07c4a919c85c9778ceac0cdfd35a548c6e784740ba069ee1422b9b5da42b00e6b79a8ca6daca5e68981d836af7bd8edd70b1088836f8b0b4646e254b36137f8358a6cd870cd7cb3d8bb446f12b717bdd231250afc79ac707c47b54bf8098731acc04d2e463cfd372c84e49cf632873baf31542120479567083b601c0f6c14b4983969fbc46c39ca00c3c9beb75c246cb4dcf9df63a491bbda15d03e31dfb1bc0b5094ed09854aacfae2f8ed5a92f126caf034454b0fa345eee0b1853dfd8908a84700b80dd17c4c3d3fc20476735fb8f418436b1a8fa6ad", 16)
c2 = int("30e04e0341f08ef61fe83127e4396bdf62091fb90b07aff457fc5508e47c9072d026cc3ef552d4a6c89e6c6b605efdeda97b3db1686f5aa8bdd0f48dcb7b6036a470815046d2f6080f26ae69543af61e30864084e44896dc0ca415fb2665b6d53117d875fc32a80660f70e2102aa41e098faea8281daef75e827ed15a0b890860e22443e1ee8d937acefd92e64209d724a79b5695449051b96ede7968d4e82298db93ce5f47bffd97f45d031b884e0788ee1f710cec19683d77448e888f74145e282e8cddfc22b4d48679fecf556f43ab4926552f9abe8f551a0fe4ce289f54b45fa424c169defef510fe4df98f3a3d99e9b64f028096087e2e5d5885599e48e", 16)

u, v = sympy.gcdex(key1.e, key2.e)[0:2]

    
m = (pow(c1, int(u), key1.n) * pow(c2, int(v), key1.n)) % key1.n


m_bytes = m.to_bytes((m.bit_length() + 7) // 8, 'big')
print(f"Message déchiffré (bytes) : {m_bytes}")